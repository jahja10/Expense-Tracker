using ErrorOr;
using SampleCkWebApp.Domain.Entities;

namespace SampleCkWebApp.Application.Users.Interfaces.Infrastructure;

public interface IUserRepository
{
    
    Task<ErrorOr<List<User>>>GetUsersAsync(CancellationToken cancellationToken);
    Task<ErrorOr<User>>GetUserByIdAsync(int id, CancellationToken cancellationToken);
    Task<ErrorOr<User>>GetUserByEmailAsync(string email, CancellationToken cancellationToken);
    Task<ErrorOr<User>>CreateUserAsync(User user, CancellationToken cancellationToken);

}
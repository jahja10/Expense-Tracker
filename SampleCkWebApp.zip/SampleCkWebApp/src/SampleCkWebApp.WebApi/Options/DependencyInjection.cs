﻿namespace SampleCkWebApp.WebApi.Options;

public class DependencyInjection
{
    
}
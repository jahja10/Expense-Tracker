﻿namespace SampleCkWebApp.WebApi;

public static class HttpContextItemKeys
{
    public const string Error = "errors";
}